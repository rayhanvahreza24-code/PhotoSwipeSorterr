# Photo Swipe Sorter

Aplikasi Android sederhana untuk menyortir foto dengan gestur:
- Geser kiri / tombol TOLAK = masuk kelompok DITOLAK
- Geser kanan / tombol PAKAI = masuk kelompok DIPAKAI
- Tombol urungkan tersedia selama proses sortir.
- Foto asli tidak dihapus. Hasil disalin ke `Pictures/PhotoSwipeSorter/DIPAKAI` dan `.../DITOLAK`.

## Membuat APK tanpa laptop (Acode + GitHub)
1. Ekstrak ZIP ini di HP.
2. Buat repository baru di https://github.com/new.
3. Unggah semua isi folder proyek ke repository, pertahankan struktur folder.
4. Pastikan file `.github/workflows/android.yml` ikut terunggah.
5. Buka tab **Actions** pada repository.
6. Pilih **Build Photo Swipe Sorter APK**, lalu tekan **Run workflow**.
7. Setelah selesai, buka hasil run dan unduh artifact `PhotoSwipeSorter-debug-apk`.
8. Ekstrak ZIP artifact, lalu pasang `app-debug.apk` di HP. Izinkan instalasi dari sumber yang Anda pilih bila Android memintanya.

## Catatan
Ini adalah prototipe awal. Periksa hasil pada beberapa foto sebelum mengandalkannya untuk sortir besar. Aplikasi tidak menghapus foto sumber.
