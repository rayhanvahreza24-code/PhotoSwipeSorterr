package com.example.photoswipesorter;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.GradientDrawable;
import android.provider.DocumentsContract;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.graphics.Color;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PICK = 101;
    ArrayList<Uri> photos = new ArrayList<>();
    ArrayList<Uri> kept = new ArrayList<>(), rejected = new ArrayList<>();
    int index = 0;
    LinearLayout root, card, actions;
    ImageView image;
    TextView counter, status, instruction;
    float downX, downY;
    String folderName = "PhotoSwipeSorter";
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildHome();
    }
    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); return t;
    }
    Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); return b;
    }
    void buildHome() {
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(18),dp(18),dp(18),dp(16)); root.setBackgroundColor(Color.rgb(247,248,252));
        TextView title = text("Photo Swipe Sorter", 25, Color.rgb(25,35,55)); title.setTypeface(null,1);
        root.addView(title, new LinearLayout.LayoutParams(-1,dp(54)));
        TextView desc = text("Pilih foto, lalu geser kanan untuk DIPAKAI atau kiri untuk DITOLAK.",15,Color.DKGRAY);
        root.addView(desc, new LinearLayout.LayoutParams(-1,dp(68)));
        Button choose = button("Pilih banyak foto"); choose.setOnClickListener(v -> pickPhotos());
        root.addView(choose, new LinearLayout.LayoutParams(-1,dp(54)));
        TextView safe = text("Foto asli tidak dihapus. Hasil sortir disimpan sebagai salinan.",13,Color.GRAY);
        root.addView(safe, new LinearLayout.LayoutParams(-1,dp(64)));
        setContentView(root);
    }
    void pickPhotos() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK);
    }
    @Override protected void onActivityResult(int req,int res,Intent data) {
        super.onActivityResult(req,res,data);
        if(req==PICK && res==RESULT_OK && data!=null) {
            photos.clear(); kept.clear(); rejected.clear(); index=0;
            if(data.getClipData()!=null) {
                for(int n=0;n<data.getClipData().getItemCount();n++) photos.add(data.getClipData().getItemAt(n).getUri());
            } else if(data.getData()!=null) photos.add(data.getData());
            if(photos.size()>0) showSorter();
            else Toast.makeText(this,"Belum ada foto dipilih",Toast.LENGTH_SHORT).show();
        }
    }
    void showSorter() {
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(14),dp(10),dp(14),dp(10)); root.setBackgroundColor(Color.rgb(247,248,252));
        counter=text("",17,Color.DKGRAY); root.addView(counter,new LinearLayout.LayoutParams(-1,dp(42)));
        instruction=text("Geser kiri: TOLAK     •     Geser kanan: PAKAI",14,Color.DKGRAY);
        root.addView(instruction,new LinearLayout.LayoutParams(-1,dp(40)));
        FrameLayout frame=new FrameLayout(this); frame.setBackground(bg(Color.WHITE,20));
        image=new ImageView(this); image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        frame.addView(image,new FrameLayout.LayoutParams(-1,-1));
        frame.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();return true;}
            if(e.getAction()==MotionEvent.ACTION_UP){
                float dx=e.getX()-downX;
                if(Math.abs(dx)>dp(55)){ decide(dx>0); return true; }
                return true;
            } return true;
        });
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,0,1); fp.setMargins(0,dp(6),0,dp(10)); root.addView(frame,fp);
        actions=new LinearLayout(this); actions.setGravity(Gravity.CENTER); actions.setOrientation(0);
        Button no=button("← TOLAK"); no.setTextColor(Color.rgb(190,45,55)); no.setOnClickListener(v->decide(false));
        Button yes=button("PAKAI →"); yes.setTextColor(Color.rgb(20,135,85)); yes.setOnClickListener(v->decide(true));
        actions.addView(no,new LinearLayout.LayoutParams(0,dp(58),1)); actions.addView(yes,new LinearLayout.LayoutParams(0,dp(58),1));
        root.addView(actions);
        Button undo=button("Urungkan foto terakhir"); undo.setOnClickListener(v->undo());
        root.addView(undo,new LinearLayout.LayoutParams(-1,dp(48)));
        setContentView(root); showCurrent();
    }
    void showCurrent() {
        if(index>=photos.size()){ showFinish(); return; }
        counter.setText("Foto "+(index+1)+" dari "+photos.size()+"   •   Dipakai "+kept.size()+" | Ditolak "+rejected.size());
        try {
            BitmapFactory.Options o=new BitmapFactory.Options(); o.inJustDecodeBounds=true;
            try(InputStream in=getContentResolver().openInputStream(photos.get(index))){BitmapFactory.decodeStream(in,null,o);}
            int sample=1; while(o.outWidth/sample>1800 || o.outHeight/sample>1800) sample*=2;
            BitmapFactory.Options opt=new BitmapFactory.Options(); opt.inSampleSize=sample;
            try(InputStream in=getContentResolver().openInputStream(photos.get(index))){Bitmap bm=BitmapFactory.decodeStream(in,null,opt); image.setImageBitmap(bm);}
        } catch(Exception ex){ image.setImageDrawable(null); Toast.makeText(this,"Foto tidak bisa dibuka",Toast.LENGTH_SHORT).show(); }
    }
    void decide(boolean use) {
        if(index>=photos.size())return;
        (use?kept:rejected).add(photos.get(index)); index++; showCurrent();
    }
    void undo() {
        if(index<=0)return; index--;
        Uri last=photos.get(index); if(!kept.isEmpty() && kept.get(kept.size()-1).equals(last)) kept.remove(kept.size()-1);
        else if(!rejected.isEmpty() && rejected.get(rejected.size()-1).equals(last)) rejected.remove(rejected.size()-1);
        showCurrent();
    }
    void showFinish() {
        root.removeAllViews();
        TextView done=text("Selesai menyortir!",24,Color.rgb(25,35,55)); done.setTypeface(null,1);
        root.addView(done,new LinearLayout.LayoutParams(-1,dp(70)));
        root.addView(text("Dipakai: "+kept.size()+" foto\\nDitolak: "+rejected.size()+" foto",19,Color.DKGRAY),new LinearLayout.LayoutParams(-1,dp(110)));
        TextView note=text("Simpan hasil ke folder di HP. Foto asli tetap utuh.",14,Color.GRAY);
        root.addView(note,new LinearLayout.LayoutParams(-1,dp(60)));
        Button save=button("Simpan 2 folder hasil"); save.setOnClickListener(v->saveResults());
        root.addView(save,new LinearLayout.LayoutParams(-1,dp(58)));
        Button restart=button("Sortir kumpulan foto lain"); restart.setOnClickListener(v->buildHome());
        root.addView(restart,new LinearLayout.LayoutParams(-1,dp(52)));
    }
    void saveResults() {
        try {
            android.content.ContentResolver cr=getContentResolver();
            Uri picked=android.provider.DocumentsContract.buildDocumentUriUsingTree(Uri.EMPTY,"");
            // Use app-created folders under Pictures through MediaStore; this avoids asking for broad storage access.
            int count=0;
            count+=copyGroup(kept,"DIPAKAI");
            count+=copyGroup(rejected,"DITOLAK");
            Toast.makeText(this,"Tersimpan "+count+" salinan di Pictures/PhotoSwipeSorter",Toast.LENGTH_LONG).show();
        } catch(Exception e){Toast.makeText(this,"Gagal menyimpan: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    int copyGroup(ArrayList<Uri> list,String group) throws Exception {
        int count=0;
        for(Uri src:list) {
            String name=getName(src); String mime=getContentResolver().getType(src); if(mime==null)mime="image/jpeg";
            ContentValues cv=new ContentValues(); cv.put(MediaStore.Images.Media.DISPLAY_NAME,group+"_"+System.currentTimeMillis()+"_"+name);
            cv.put(MediaStore.Images.Media.MIME_TYPE,mime);
            cv.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/PhotoSwipeSorter/"+group);
            Uri out=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);
            if(out!=null) {
                try(InputStream in=getContentResolver().openInputStream(src); OutputStream os=getContentResolver().openOutputStream(out)) {
                    byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)os.write(buf,0,n);
                } catch(Exception ex){getContentResolver().delete(out,null,null); throw ex;}
                count++;
            }
        }
        return count;
    }
    String getName(Uri u) {
        String n="foto.jpg";
        try(Cursor c=getContentResolver().query(u,null,null,null,null)){
            if(c!=null && c.moveToFirst()){int k=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(k>=0)n=c.getString(k);}
        }catch(Exception ignored){}
        return n.replaceAll("[^a-zA-Z0-9._-]","_");
    }
}
