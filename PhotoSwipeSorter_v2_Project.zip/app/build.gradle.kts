plugins { id("com.android.application") }

android {
    namespace = "com.example.photoswipesorter"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.photoswipesorter"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
