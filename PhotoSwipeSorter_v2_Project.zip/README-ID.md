# Photo Swipe Sorter v2

Proyek Android Java untuk dibangun menjadi APK melalui GitHub Actions.

Fitur pada kode v2: swipe kiri/kanan, Undo, daftar preview foto, info nama/ukuran/resolusi, hitungan progres, simpan salinan ke album Pictures/PhotoSwipeSorter/DIPAKAI dan DITOLAK, serta panel ringkasan album. Foto sumber tidak dihapus.

Catatan: deteksi duplikat konten dan penyimpanan otomatis setiap geseran belum diimplementasikan pada build ini; jangan menganggap keduanya tersedia. Tema gelap masih berupa tombol pengaturan awal dan belum menerapkan palet gelap penuh.

## Build lewat HP
1. Unggah isi ZIP ini ke root repository GitHub (bukan ZIP sebagai satu file).
2. Pastikan `.github/workflows/android.yml` ikut terunggah.
3. Buka Actions, jalankan Build Photo Swipe Sorter APK.
4. Unduh artifact `PhotoSwipeSorter-debug-apk` dan instal `app-debug.apk`.
