# iSwipe — Android + Supabase starter

Isi paket:
- Proyek Android dasar dari ZIP iSwipe sebelumnya (pilih foto, swipe, Undo, salin hasil).
- Utilitas Java `DuplicateScanner` untuk menemukan file yang identik byte-per-byte dengan SHA-256. Ini belum mendeteksi foto yang hanya mirip.
- Antarmuka awal Client Gallery berbasis web.
- Skema awal Supabase dengan tabel galeri, foto, pilihan klien, dan RLS.

## Status jujur
Paket ini adalah starter project, BUKAN aplikasi komersial lengkap dan BUKAN APK siap instal. Deteksi duplikat sudah disediakan sebagai kelas utilitas, tetapi belum dipasang ke layar Android. Client Gallery adalah antarmuka awal dan belum bisa online sampai Edge Functions, autentikasi, upload, signed URL, serta kontrol keamanan dikerjakan dan diuji. Lihat `supabase/EDGE_FUNCTIONS_TODO.md`.

Jangan unggah foto klien atau membuka galeri ke publik sebelum backend aman. Jangan masukkan Supabase service-role key ke aplikasi atau browser.
