-- iSwipe starter schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.galleries (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  client_name text,
  access_code_hash text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz,
  is_active boolean not null default true
);

create table if not exists public.gallery_photos (
  id uuid primary key default gen_random_uuid(),
  gallery_id uuid not null references public.galleries(id) on delete cascade,
  storage_path text not null,
  file_name text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.client_selections (
  id uuid primary key default gen_random_uuid(),
  photo_id uuid not null references public.gallery_photos(id) on delete cascade,
  selection_token_hash text not null,
  is_favorite boolean not null default true,
  created_at timestamptz not null default now(),
  unique(photo_id, selection_token_hash)
);

alter table public.galleries enable row level security;
alter table public.gallery_photos enable row level security;
alter table public.client_selections enable row level security;

create policy "Owners manage galleries"
on public.galleries for all to authenticated
using (auth.uid() = owner_id) with check (auth.uid() = owner_id);

create policy "Owners manage gallery photos"
on public.gallery_photos for all to authenticated
using (exists (select 1 from public.galleries g where g.id = gallery_id and g.owner_id = auth.uid()))
with check (exists (select 1 from public.galleries g where g.id = gallery_id and g.owner_id = auth.uid()));

-- Client access intentionally goes through secure Edge Functions, not anonymous table policies.
-- Keep Storage bucket private. Never expose service_role key in APK or browser.
