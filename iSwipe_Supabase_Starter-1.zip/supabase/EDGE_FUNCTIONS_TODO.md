# Wajib sebelum Client Gallery online dipakai klien

Frontend di `client-gallery/` adalah kerangka antarmuka. Buat dan deploy Edge Functions berikut:
1. `client-gallery-access`: verifikasi kode akses di server, cek masa berlaku, lalu kembalikan URL foto bertanda tangan (signed URL) yang berumur pendek dan token seleksi.
2. `client-gallery-select`: validasi token, pastikan foto bagian dari galeri yang sama, lalu simpan pilihan favorit.
3. Endpoint privat untuk fotografer membuat galeri, mengunggah foto, melihat pilihan, menonaktifkan link, dan menghapus galeri.

Gunakan bucket Storage privat bernama `gallery-photos`. Simpan `SUPABASE_SERVICE_ROLE_KEY` hanya di secrets Edge Functions. Jangan pernah menaruh service-role key di APK, JavaScript browser, atau repository. Tambahkan pembatasan percobaan kode, batas ukuran/jenis file, masa berlaku tautan, autentikasi fotografer, dan log audit. Jangan gunakan foto klien sungguhan sebelum semua kontrol ini diuji.
