package com.example.iswipe;

import android.content.ContentResolver;
import android.net.Uri;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;

/** Groups byte-identical files using SHA-256. Does not delete anything. */
public final class DuplicateScanner {
    private DuplicateScanner() {}
    public static ArrayList<ArrayList<Uri>> findExactDuplicates(ContentResolver resolver, ArrayList<Uri> photos) {
        HashMap<String, ArrayList<Uri>> groups = new HashMap<>();
        for (Uri uri : photos) {
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                try (InputStream in = resolver.openInputStream(uri)) {
                    if (in == null) continue;
                    byte[] buffer = new byte[65536]; int n;
                    while ((n = in.read(buffer)) != -1) md.update(buffer, 0, n);
                }
                StringBuilder key = new StringBuilder();
                for (byte b : md.digest()) key.append(String.format(java.util.Locale.ROOT, "%02x", b));
                groups.computeIfAbsent(key.toString(), k -> new ArrayList<>()).add(uri);
            } catch (Exception ignored) { }
        }
        ArrayList<ArrayList<Uri>> duplicates = new ArrayList<>();
        for (ArrayList<Uri> group : groups.values()) if (group.size() > 1) duplicates.add(group);
        return duplicates;
    }
}
