// UI scaffold. Requires secure Supabase Edge Functions before public use.
const form=document.querySelector('#access'),msg=document.querySelector('#message'),grid=document.querySelector('#gallery');
form.addEventListener('submit',async e=>{e.preventDefault();grid.innerHTML='';msg.textContent='Galeri online belum dikonfigurasi.';
const cfg=window.ISWIPE_CONFIG||{};if(!cfg.edgeFunctionBase)return;
try{const r=await fetch(cfg.edgeFunctionBase+'/client-gallery-access',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({access_code:document.querySelector('#code').value.trim()})});
if(!r.ok)throw Error('Kode salah atau galeri tidak tersedia');const d=await r.json();msg.textContent=d.title||'Pilih foto favorit';
d.photos.forEach(p=>{const card=document.createElement('article');card.className='photo';const img=document.createElement('img');img.src=p.signed_url;img.alt=p.file_name||'Foto';const b=document.createElement('button');b.textContent='♡ Pilih favorit';b.onclick=async()=>{b.disabled=true;try{const x=await fetch(cfg.edgeFunctionBase+'/client-gallery-select',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+d.selection_token},body:JSON.stringify({photo_id:p.id,favorite:true})});if(!x.ok)throw Error();b.textContent='✓ Dipilih';}catch{b.disabled=false;b.textContent='Coba lagi';}};card.append(img,b);grid.append(card);});
}catch(err){msg.textContent=err.message;}
});