# iSwipe — Android

Aplikasi Android sederhana untuk menyortir foto dengan swipe:
- Geser kiri / tombol ✕: salin foto ke `Pictures/iSwipe/Bad Photos`
- Geser kanan / tombol ♥: salin foto ke `Pictures/iSwipe/Good Photos`
- Pilih banyak foto sekaligus melalui tombol **Tambahkan Foto**
- Lihat kembali foto Good dan Bad dari tab folder
- Undo untuk membatalkan sortir terakhir (salinan hasil sortir ikut dihapus)

## Cara membuka di Android Studio
1. Ekstrak ZIP.
2. Buka Android Studio → **Open** → pilih folder `iSwipe-Android`.
3. Tunggu Gradle Sync selesai (butuh internet untuk mengunduh Gradle dan plugin).
4. Sambungkan HP Android dengan USB debugging atau gunakan emulator.
5. Tekan **Run**.

## Cara membuat APK
Android Studio → **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Penyimpanan foto
iSwipe membuat **salinan** foto yang dipilih ke folder publik Pictures/iSwipe/Good Photos atau Bad Photos. Foto asli tidak dihapus atau dipindahkan. Android akan menampilkan folder tersebut di aplikasi galeri setelah MediaStore memperbarui indeks.

## Persyaratan
- Android Studio dengan Android SDK 35
- JDK 17
- Android 10 (API 29) atau lebih baru

## GitHub
Buat repository baru di GitHub, ekstrak ZIP, lalu upload seluruh isi folder ini. Jangan upload folder `build/`, `.gradle/`, atau `local.properties`.

## Jika GitHub Actions gagal karena JVM target
Project ini mengatur target Java dan Kotlin ke JVM 17 di `app/build.gradle.kts`.
Pastikan workflow GitHub Actions juga memakai JDK 17 (`actions/setup-java` dengan `java-version: '17'`).
