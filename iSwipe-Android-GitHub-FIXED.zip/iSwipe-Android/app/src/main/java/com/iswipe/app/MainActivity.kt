package com.iswipe.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.database.Cursor
import java.io.IOException

class MainActivity : Activity() {
    private data class Photo(val uri: Uri, val name: String)
    private data class Decision(val photo: Photo, val folder: String, val savedUri: Uri)

    private val queue = mutableListOf<Photo>()
    private val good = mutableListOf<Photo>()
    private val bad = mutableListOf<Photo>()
    private val decisions = mutableListOf<Decision>()
    private var index = 0
    private lateinit var root: LinearLayout
    private lateinit var photoView: ImageView
    private lateinit var titleView: TextView
    private lateinit var statsView: TextView
    private lateinit var progressView: TextView
    private lateinit var galleryPanel: LinearLayout

    private val yellow = Color.rgb(255, 204, 45)
    private val ink = Color.rgb(43, 39, 24)
    private val muted = Color.rgb(125, 119, 105)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        render()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(ink)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun button(label: String, color: Int, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setTextColor(ink)
            setBackgroundColor(color)
            isAllCaps = false
            textSize = 14f
            setOnClickListener { action() }
        }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = text("✳  iSwipe", 27f, true)
        header.addView(brand, LinearLayout.LayoutParams(0, dp(52), 1f))
        header.addView(text("PHOTO SORTER", 10f, true))
        root.addView(header)

        root.addView(text("Your gallery, beautifully organized.", 18f, true).apply {
            setPadding(0, dp(8), 0, dp(3))
        })
        root.addView(text("Geser kiri untuk jelek, kanan untuk bagus.", 13f).apply {
            setTextColor(muted)
            setPadding(0, 0, 0, dp(12))
        })

        root.addView(button("＋  Tambahkan Foto", yellow) { pickPhotos() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(12) })

        statsView = text("0 total     ♥  0 bagus     ✕  0 jelek", 13f, true)
        statsView.gravity = Gravity.CENTER
        statsView.setPadding(0, dp(10), 0, dp(10))
        root.addView(statsView)

        titleView = text("Sortir Foto", 18f, true)
        root.addView(titleView)
        progressView = text("Tambahkan foto untuk mulai", 12f).apply {
            setTextColor(muted)
            setPadding(0, dp(3), 0, dp(8))
        }
        root.addView(progressView)

        photoView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(247, 246, 241))
            contentDescription = "Foto yang sedang disortir"
        }
        root.addView(photoView, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            height = dp(280)
        })
        photoView.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f
            var downY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.x
                        downY = event.y
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val dx = event.x - downX
                        val dy = event.y - downY
                        if (kotlin.math.abs(dx) > dp(65) && kotlin.math.abs(dx) > kotlin.math.abs(dy)) {
                            decide(if (dx > 0) "Good Photos" else "Bad Photos")
                        }
                        return true
                    }
                }
                return true
            }
        })

        val actions = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, dp(10))
        }
        actions.addView(button("✕  Jelek", Color.rgb(255, 232, 229)) { decide("Bad Photos") },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(8) })
        actions.addView(button("↶ Undo", Color.LTGRAY) { undo() },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(8) })
        actions.addView(button("♥  Bagus", Color.rgb(231, 246, 222)) { decide("Good Photos") },
            LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(actions)

        val folders = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        folders.addView(button("💚 Good Photos", Color.rgb(231, 246, 222)) { showFolder("Good Photos") },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        folders.addView(button("🗑 Bad Photos", Color.rgb(255, 232, 229)) { showFolder("Bad Photos") },
            LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(folders)

        galleryPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        root.addView(galleryPanel)
        setContentView(root)
    }

    private fun pickPhotos() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, 100)
    }

    @Deprecated("Uses activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 100 || resultCode != RESULT_OK || data == null) return
        val selected = mutableListOf<Uri>()
        data.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) selected.add(clip.getItemAt(i).uri)
        } ?: data.data?.let { selected.add(it) }
        selected.forEach { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            val name = queryName(uri) ?: "photo_${queue.size + 1}.jpg"
            if (queue.none { it.uri == uri } && good.none { it.uri == uri } && bad.none { it.uri == uri }) {
                queue.add(Photo(uri, name))
            }
        }
        render()
    }

    private fun queryName(uri: Uri): String? {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) cursor.getString(0) else null
        } catch (_: Exception) { null } finally { cursor?.close() }
    }

    private fun saveCopy(photo: Photo, folder: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "${System.currentTimeMillis()}_${photo.name}")
            put(MediaStore.Images.Media.MIME_TYPE, contentResolver.getType(photo.uri) ?: "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/iSwipe/$folder")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val destination = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Tidak bisa membuat folder tujuan")
        try {
            contentResolver.openInputStream(photo.uri).use { input ->
                contentResolver.openOutputStream(destination).use { output ->
                    if (input == null || output == null) throw IOException("Tidak bisa membaca foto")
                    input.copyTo(output)
                }
            }
            val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            contentResolver.update(destination, done, null, null)
            return destination
        } catch (e: Exception) {
            contentResolver.delete(destination, null, null)
            throw e
        }
    }

    private fun decide(folder: String) {
        if (index >= queue.size) return
        val photo = queue[index]
        try {
            val saved = saveCopy(photo, folder)
            if (folder == "Good Photos") good.add(photo) else bad.add(photo)
            decisions.add(Decision(photo, folder, saved))
            index++
            render()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menyimpan: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun undo() {
        val last = decisions.lastOrNull() ?: return
        contentResolver.delete(last.savedUri, null, null)
        if (last.folder == "Good Photos") good.remove(last.photo) else bad.remove(last.photo)
        index = (index - 1).coerceAtLeast(0)
        decisions.removeAt(decisions.lastIndex)
        render()
    }

    private fun render() {
        statsView.text = "${queue.size + good.size + bad.size - good.size - bad.size} dipilih   ♥ ${good.size} bagus   ✕ ${bad.size} jelek"
        val photo = queue.getOrNull(index)
        progressView.text = if (photo == null) {
            if (queue.isEmpty()) "Belum ada foto dipilih" else "Semua foto sudah disortir 🎉"
        } else "${index + 1} dari ${queue.size} foto"
        if (photo == null) {
            photoView.setImageDrawable(null)
            photoView.setBackgroundColor(Color.rgb(247, 246, 241))
            photoView.setOnClickListener { if (queue.isEmpty()) pickPhotos() }
        } else {
            photoView.setBackgroundColor(Color.WHITE)
            photoView.setImageURI(photo.uri)
        }
    }

    private fun showFolder(folder: String) {
        galleryPanel.removeAllViews()
        galleryPanel.visibility = View.VISIBLE
        galleryPanel.addView(text("📁 $folder", 17f, true))
        val list = if (folder == "Good Photos") good else bad
        if (list.isEmpty()) galleryPanel.addView(text("Belum ada foto di folder ini.", 13f))
        list.forEach { photo ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(5), 0, dp(5))
            }
            val thumb = ImageView(this).apply {
                setImageURI(photo.uri)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            row.addView(thumb, LinearLayout.LayoutParams(dp(58), dp(58)))
            row.addView(text(photo.name, 12f).apply { setPadding(dp(10), 0, 0, 0) })
            galleryPanel.addView(row)
        }
        galleryPanel.addView(button("Tutup folder", Color.LTGRAY) { galleryPanel.visibility = View.GONE })
    }
}
